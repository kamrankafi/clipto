
function videoListCtrl($scope) {
  
    // Your code...
    $scope.load = function () {}

    $scope.load();
}
