
function sprintCtrl($scope) {
  
    // Your code...
    $scope.load = function () {}

    $scope.load();
}
