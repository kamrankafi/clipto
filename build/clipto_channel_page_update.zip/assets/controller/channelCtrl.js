
function channelCtrl($scope) {
  
    // Your code...
    $scope.load = function () {}

    $scope.load();
}
