
function panelCtrl($scope) {
  
    // Your code...
    $scope.load = function () {}

    $scope.load();
}
